#Session Parser)
import re
import os
from datetime import datetime

class SessionParser:
    def __init__(self):
        # Update path to poker_tracker directory
        self.export_dir = "poker_tracker/DB_Import_Files"
        if not os.path.exists(self.export_dir):
            os.makedirs(self.export_dir)

    def parse_file(self, input_file):
        try:
            # Read the content
            with open(input_file, "r", encoding="utf-8") as file:
                content = file.read()  # Read entire file as one string

            # Define a list to store parsed sessions
            sessions = []
            
            # Find all table entries (they start with a date and end with a result)
            table_entries = re.finditer(
                r"(Jan \d{1,2}, \d{1,2}:\d{2} [APM]{2})\n"  # Date and time
                r"((?:\d+h )?\d+m \d+s)\n"  # Duration
                r"(Hold'em|Omaha)\n"  # Game format
                r"([\d.]+ SC / [\d.]+ SC)\n"  # Stakes
                r"(\d+)\n"  # Hands played
                r"([+-][\d.]+ SC)",  # Result
                content
            )

            for match in table_entries:
                start_time = match.group(1)
                duration = match.group(2)
                game_format = match.group(3)
                stake = match.group(4)
                hands_played = match.group(5)
                result = match.group(6).replace(" SC", "")

                # Convert SC to dollars
                result_dollars = f"${float(result)}" if float(result) >= 0 else f"-${abs(float(result))}"

                # Format output
                session_output = (
                    f"Start time ({start_time}) Duration ({duration}) "
                    f"Format ({game_format}) Stake ({stake}) HandsPlayed ({hands_played}) Result ({result_dollars})"
                )
                
                sessions.append(session_output)

            # Generate output filename with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = os.path.join(self.export_dir, f'parsed_sessions_{timestamp}.txt')

            # Write parsed sessions to file
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(sessions))

            return output_file
            
        except Exception as e:
            print(f"Error parsing file: {str(e)}")
            raise