import tkinter as tk
from tkinter import ttk, messagebox
import logging
from .scraper import WebScraper
from .utils import setup_logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
from selenium.webdriver.common.keys import Keys
import os
import datetime

class WebScraperGUI:
    def __init__(self, root):
        self.logger = setup_logging()
        self.logger.info("Starting Web Scraper application")
        
        self.root = root
        self.scraper = WebScraper()
        self.driver = None  # Store driver instance as class variable
        self._init_ui()
    
    def _init_ui(self):
        # URL input with explanation
        url_label = ttk.Label(self.root, text="Website URL:")
        url_label.pack(pady=5)
        
        self.url_entry = ttk.Entry(self.root, width=50)
        self.url_entry.pack(pady=5)
        
        # Element type selection
        ttk.Label(self.root, text="What do you want to scrape?").pack(pady=5)
        self.element_type = ttk.Combobox(self.root, width=47, state='readonly')
        self.element_type.pack(pady=5)
        self.element_type['values'] = [
            "All Text Content",
            "All paragraphs (text content)",
            "Main article content",
            "Headlines/Titles (h1, h2, h3)",
            "Navigation menu items",
            "Links (URLs)",
            "Custom CSS selector",
            "Specific div by class/id"
        ]
        self.element_type.set("All paragraphs (text content)")
        
        # Scrape button
        ttk.Button(self.root, text="Scrape", command=self.scrape).pack(pady=10)
        
        # Result area
        ttk.Label(self.root, text="Scraped Content:").pack(pady=5)
        self.result_text = tk.Text(self.root, height=10, width=50)
        self.result_text.pack(pady=10)

        # Add this after the result text area
        self.progress_frame = ttk.Frame(self.root)
        self.progress_frame.pack(pady=5, fill='x', padx=10)
        
        self.progress_bar = ttk.Progressbar(
            self.progress_frame, 
            mode='indeterminate',
            length=300
        )
        self.progress_bar.pack(pady=5)
        self.progress_frame.pack_forget()  # Hide initially

        # Add Continue button (hidden by default)
        self.continue_button = tk.Button(
            self.root,
            text="Continue After Login",
            command=self.continue_after_login,
            bg='green',
            fg='white'
        )

        # Add Save & Close button (hidden by default)
        self.save_close_button = tk.Button(
            self.root,
            text="Save & Close",
            command=self.save_and_close,
            bg='blue',
            fg='white'
        )

    def scrape(self):
        url = self.url_entry.get()
        
        try:
            self.result_text.insert(tk.END, "Initializing Chrome browser...\n")
            self.root.update()
            options = webdriver.ChromeOptions()
            
            # Use default Chrome profile
            options.add_argument('--user-data-dir=/Users/shane/Library/Application Support/Google/Chrome')
            options.add_argument('--profile-directory=Default')
            
            # Other necessary options
            options.add_argument('--start-maximized')
            options.add_argument('--disable-gpu')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            
            self.driver = webdriver.Chrome(
                service=Service(ChromeDriverManager().install()),
                options=options
            )
            
            self.result_text.insert(tk.END, f"Navigating to {url}...\n")
            self.root.update()
            self.driver.get(url)
            
            # Wait for page to fully load
            self.result_text.insert(tk.END, "Waiting for page to load...\n")
            self.root.update()
            
            # Wait for any dynamic content to load
            wait = WebDriverWait(self.driver, 10)
            wait.until(lambda driver: driver.execute_script('return document.readyState') == 'complete')
            
            # Additional wait for any AJAX content
            time.sleep(3)
            
            # Show continue button
            self.continue_button.pack(pady=10)
            self.result_text.insert(tk.END, "Click 'Continue After Login' when the page is fully loaded.\n")
            
        except Exception as e:
            self.logger.error(f"Error during scraping: {str(e)}", exc_info=True)
            messagebox.showerror("Error", str(e))
            if self.driver:
                self.driver.quit()

    def continue_after_login(self):
        """Continue scraping after page is loaded"""
        try:
            self.continue_button.pack_forget()  # Hide continue button
            
            # Get the page text
            self.result_text.insert(tk.END, "Getting page content...\n")
            self.root.update()
            
            # Execute JavaScript to get all text content
            self.page_text = self.driver.execute_script("return document.body.innerText;")
            
            # Search functionality
            if "Total Hands:" in self.page_text:
                lines = self.page_text.split('\n')
                for line in lines:
                    if "Total Hands:" in line:
                        self.result_text.insert(tk.END, f"Found: {line.strip()}\n")
                        index = lines.index(line)
                        start = max(0, index - 2)
                        end = min(len(lines), index + 3)
                        self.result_text.insert(tk.END, "\nContext:\n")
                        for context_line in lines[start:end]:
                            self.result_text.insert(tk.END, f"{context_line.strip()}\n")
            else:
                self.result_text.insert(tk.END, "Could not find 'Total Hands:' text\n")
                self.result_text.insert(tk.END, "First 1000 characters of page text:\n")
                self.result_text.insert(tk.END, self.page_text[:1000] + "...\n")
            
            # Show save & close button
            self.result_text.insert(tk.END, "\nClick 'Save & Close' to export content and close browser\n")
            self.save_close_button.pack(pady=10)
            
        except Exception as e:
            self.logger.error(f"Error after loading: {str(e)}", exc_info=True)
            messagebox.showerror("Error", str(e))
            if self.driver:
                self.driver.quit()

    def save_and_close(self):
        """Save content to file and close browser"""
        try:
            # Create output directory if it doesn't exist
            output_dir = "output"
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            
            # Generate filename with timestamp
            timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = os.path.join(output_dir, f'page_content_{timestamp}.txt')
            
            # Write full content to file
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(self.page_text)
            
            self.result_text.insert(tk.END, f"\nFull page content saved to: {filename}\n")
            
            # Parse the saved content
            try:
                from .Session_Parser import SessionParser
                parser = SessionParser()
                parsed_file = parser.parse_file(filename)
                self.result_text.insert(tk.END, f"Parsed sessions saved to: {parsed_file}\n")
            except Exception as parse_error:
                self.logger.error(f"Error parsing sessions: {str(parse_error)}", exc_info=True)
                messagebox.showerror("Parsing Error", f"Error parsing sessions: {str(parse_error)}")
            
            self.save_close_button.pack_forget()
            
            # Close browser
            if self.driver:
                self.driver.quit()
                self.driver = None
            
        except Exception as e:
            self.logger.error(f"Error saving content: {str(e)}", exc_info=True)
            messagebox.showerror("Error", str(e))

    def get_selector_from_choice(self):
        selection = self.element_type.get()
        selectors = {
            "All Text Content": "*",  # This will get all elements
            "All paragraphs (text content)": "p",
            "Main article content": "article, .article, .post, .content, main",
            "Headlines/Titles (h1, h2, h3)": "h1, h2, h3",
            "Navigation menu items": "nav a, .menu a, .navigation a",
            "Links (URLs)": "a",
            "Custom CSS selector": self.selector_entry.get(),
            "Specific div by class/id": "div[class], div[id]"
        }
        return selectors[selection]

    def on_element_select(self, event=None):
        """Show/hide custom selector frame based on selection"""
        if self.element_type.get() == "Custom CSS selector":
            self.custom_frame.pack(pady=5)
        else:
            self.custom_frame.pack_forget()

    # ... rest of existing GUI methods ... 