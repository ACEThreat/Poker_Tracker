"""Web Scraper - A GUI tool for scraping web content."""

__version__ = "0.1.0" 