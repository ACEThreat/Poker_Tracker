import os
import logging
import datetime

def setup_logging():
    """Logging setup moved to utils"""
    if not os.path.exists('logs'):
        os.makedirs('logs')
        
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'logs/webscraper_{timestamp}.log'
    
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )
    
    return logging.getLogger('WebScraper') 