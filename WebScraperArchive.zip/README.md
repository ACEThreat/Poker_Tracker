# Web Scraper

A GUI tool for easily scraping content from websites.

## Installation 