import tkinter as tk
from tkinter import ttk, messagebox
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import logging
import datetime
import os

class WebScraperGUI:
    def __init__(self, root):
        # Set up logging
        self.setup_logging()
        self.logger = logging.getLogger('WebScraper')
        self.logger.info("Starting Web Scraper application")
        
        self.root = root
        self.root.title("Web Scraper")
        
        # URL input with explanation
        url_label = ttk.Label(root, text="Website URL:")
        url_label.pack(pady=5)
        url_tooltip = ("Enter the full website address you want to scrape from.\n"
                      "Example: https://www.example.com")
        url_label.bind("<Enter>", lambda e: self.show_tooltip(e, url_tooltip))
        url_label.bind("<Leave>", self.hide_tooltip)
        
        self.url_entry = ttk.Entry(root, width=50)
        self.url_entry.pack(pady=5)
        
        # Element type selection
        ttk.Label(root, text="What do you want to scrape?").pack(pady=5)
        self.element_type = ttk.Combobox(root, width=47, state='readonly')
        self.element_type.pack(pady=5)
        self.element_type['values'] = [
            "All paragraphs (text content)",
            "Main article content",
            "Headlines/Titles (h1, h2, h3)",
            "Navigation menu items",
            "Links (URLs)",
            "Custom CSS selector"
        ]
        self.element_type.bind('<<ComboboxSelected>>', self.on_element_select)
        self.element_type.set("All paragraphs (text content)")
        
        # Custom selector frame (initially hidden)
        self.custom_frame = ttk.Frame(root)
        selector_label = ttk.Label(self.custom_frame, text="Custom CSS Selector:")
        selector_label.pack(pady=5)
        selector_tooltip = ("Enter the CSS selector to find the element you want to scrape.\n"
                          "Examples:\n"
                          "• .classname - finds elements with class 'classname'\n"
                          "• #id - finds element with ID 'id'\n"
                          "• div.content p - finds paragraphs inside div with class 'content'")
        selector_label.bind("<Enter>", lambda e: self.show_tooltip(e, selector_tooltip))
        selector_label.bind("<Leave>", self.hide_tooltip)
        
        self.selector_entry = ttk.Entry(self.custom_frame, width=50)
        self.selector_entry.pack(pady=5)
        
        # Example text
        example_text = ("Examples:\n"
                       "URL: https://www.example.com\n"
                       "CSS Selector: .main-content p")
        ttk.Label(root, text=example_text, justify=tk.LEFT).pack(pady=5)
        
        # Scrape button
        ttk.Button(root, text="Scrape", command=self.scrape).pack(pady=10)
        
        # Result area with label
        ttk.Label(root, text="Scraped Content:").pack(pady=5)
        self.result_text = tk.Text(root, height=10, width=50)
        self.result_text.pack(pady=10)
    
    def setup_logging(self):
        # Create logs directory if it doesn't exist
        if not os.path.exists('logs'):
            os.makedirs('logs')
            
        # Set up logging with timestamp
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = f'logs/webscraper_{timestamp}.log'
        
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()  # Also print to console
            ]
        )
    
    def show_tooltip(self, event, text):
        x, y, _, _ = event.widget.bbox("insert")
        x += event.widget.winfo_rootx() + 25
        y += event.widget.winfo_rooty() + 20
        
        self.tooltip = tk.Toplevel(self.root)
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.wm_geometry(f"+{x}+{y}")
        
        label = ttk.Label(self.tooltip, text=text, justify=tk.LEFT,
                         background="#ffffe0", relief="solid", borderwidth=1)
        label.pack()
    
    def hide_tooltip(self, event=None):
        if hasattr(self, 'tooltip'):
            self.tooltip.destroy()
    
    def on_element_select(self, event=None):
        selection = self.element_type.get()
        if selection == "Custom CSS selector":
            self.custom_frame.pack()
        else:
            self.custom_frame.pack_forget()

    def get_selector_from_choice(self):
        selection = self.element_type.get()
        self.logger.debug(f"Getting selector for choice: {selection}")
        selectors = {
            "All paragraphs (text content)": "p",
            "Main article content": "article, .article, .post, .content, main",
            "Headlines/Titles (h1, h2, h3)": "h1, h2, h3",
            "Navigation menu items": "nav a, .menu a, .navigation a",
            "Links (URLs)": "a",
            "Custom CSS selector": self.selector_entry.get()
        }
        selector = selectors[selection]
        self.logger.debug(f"Selected selector: {selector}")
        return selector

    def scrape(self):
        url = self.url_entry.get()
        selector = self.get_selector_from_choice()
        
        self.logger.info(f"Starting scrape operation for URL: {url}")
        self.logger.info(f"Using selector: {selector}")
        
        if not url:
            self.logger.error("No URL provided")
            messagebox.showerror("Error", "Please enter a URL")
            return
        
        if self.element_type.get() == "Custom CSS selector" and not selector:
            self.logger.error("No CSS selector provided for custom selection")
            messagebox.showerror("Error", "Please enter a CSS selector")
            return
        
        try:
            self.logger.debug("Initializing Chrome options")
            options = webdriver.ChromeOptions()
            options.add_argument('--headless')
            
            self.logger.debug("Starting Chrome driver")
            driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
            
            self.logger.info(f"Navigating to URL: {url}")
            driver.get(url)
            
            # Try multiple selectors for main content options
            if ',' in selector:
                self.logger.debug("Multiple selectors detected, trying each one")
                elements = []
                for sel in selector.split(','):
                    try:
                        sel = sel.strip()
                        self.logger.debug(f"Trying selector: {sel}")
                        found_elements = driver.find_elements(By.CSS_SELECTOR, sel)
                        self.logger.debug(f"Found {len(found_elements)} elements with selector {sel}")
                        elements.extend(found_elements)
                    except Exception as e:
                        self.logger.warning(f"Failed to find elements with selector {sel}: {str(e)}")
                        continue
            else:
                self.logger.debug(f"Waiting for elements with selector: {selector}")
                elements = WebDriverWait(driver, 10).until(
                    EC.presence_of_all_elements_located((By.CSS_SELECTOR, selector))
                )
                self.logger.debug(f"Found {len(elements)} elements")
            
            # Collect text from all found elements
            if self.element_type.get() == "Links (URLs)":
                self.logger.debug("Processing URLs from links")
                result = '\n'.join(element.get_attribute('href') for element in elements if element.get_attribute('href'))
                self.logger.debug(f"Found {result.count('\n') + 1} URLs")
            else:
                self.logger.debug("Processing text content from elements")
                result = '\n\n'.join(element.text for element in elements if element.text.strip())
            
            self.logger.debug("Updating result text area")
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, result)
            
            self.logger.debug("Closing Chrome driver")
            driver.quit()
            
            self.logger.info("Scraping completed successfully")
            
        except Exception as e:
            self.logger.error(f"Error during scraping: {str(e)}", exc_info=True)
            messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = WebScraperGUI(root)
    root.mainloop() 