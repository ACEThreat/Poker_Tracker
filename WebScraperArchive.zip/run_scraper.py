#!/usr/bin/env python3
import tkinter as tk
from src.web_scraper.gui import WebScraperGUI
import logging
import os
from datetime import datetime

def main():
    """Initialize and run the Web Scraper application."""
    # Set up logging
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"webscraper_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    root = tk.Tk()
    root.title("Web Scraper")
    
    # Set minimum window size
    root.minsize(600, 400)
    
    # Center window on screen
    window_width = 600
    window_height = 600
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    center_x = int(screen_width/2 - window_width/2)
    center_y = int(screen_height/2 - window_height/2)
    root.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')
    
    app = WebScraperGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main() 